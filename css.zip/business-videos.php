<?php include "header.php" ?>
<img src="img/innr-banner.jpg" alt="" class="w-100">

<section class="py-12 bg-2">
    <div class="container">
        <div class="row align-items-center justify-content-between">
            <div class="col-12">
                <div class="slider-title wow bounceInLeft text-center" data-wow-duration="1s">
                    Business Videos<span class="color-3">.</span>
                </div>
            </div>
            <div class="col-12">
                <div class="slider-title wow bounceInLeft" data-wow-duration="1s">
                    Explainer Videos<span class="color-3">.</span>
                </div>
            </div>
            <div class="col-6 col-md-4 text-center pt-9 mx-auto">
                <iframe width="100%" height="190" src="https://www.youtube.com/embed/t0lc1_4ADXw" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
            <div class="col-6 col-md-4 text-center pt-9 mx-auto">
                <iframe width="100%" height="190" src="https://www.youtube.com/embed/QE_Cq9icNTo" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
            <div class="col-6 col-md-4 text-center pt-9 mx-auto">
                <iframe width="100%" height="190" src="https://www.youtube.com/embed/Nn6yrpIhROE" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
            <div class="col-12">
                <div class="slider-title wow bounceInLeft" data-wow-duration="1s">
                    Business Videos<span class="color-3">.</span>
                </div>
            </div>
            <div class="col-6 col-md-4 text-center pt-9 mx-auto">
                <iframe width="100%" height="190" src="https://www.youtube.com/embed/t0lc1_4ADXw" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
            <div class="col-6 col-md-4 text-center pt-9 mx-auto">
                <iframe width="100%" height="190" src="https://www.youtube.com/embed/QE_Cq9icNTo" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
            <div class="col-6 col-md-4 text-center pt-9 mx-auto">
                <iframe width="100%" height="190" src="https://www.youtube.com/embed/Nn6yrpIhROE" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
            <div class="col-12">
                <div class="slider-title wow bounceInLeft" data-wow-duration="1s">
                    Advertisments<span class="color-3">.</span>
                </div>
            </div>
            <div class="col-6 col-md-4 text-center pt-9 mx-auto">
                <iframe width="100%" height="190" src="https://www.youtube.com/embed/t0lc1_4ADXw" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
            <div class="col-6 col-md-4 text-center pt-9 mx-auto">
                <iframe width="100%" height="190" src="https://www.youtube.com/embed/QE_Cq9icNTo" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
            <div class="col-6 col-md-4 text-center pt-9 mx-auto">
                <iframe width="100%" height="190" src="https://www.youtube.com/embed/Nn6yrpIhROE" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
            <div class="col-12">
                <div class="slider-title wow bounceInLeft" data-wow-duration="1s">
                    Interior Videos<span class="color-3">.</span>
                </div>
            </div>
            <div class="col-6 col-md-4 text-center pt-9 mx-auto">
                <iframe width="100%" height="190" src="https://www.youtube.com/embed/t0lc1_4ADXw" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
            <div class="col-6 col-md-4 text-center pt-9 mx-auto">
                <iframe width="100%" height="190" src="https://www.youtube.com/embed/QE_Cq9icNTo" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
            <div class="col-6 col-md-4 text-center pt-9 mx-auto">
                <iframe width="100%" height="190" src="https://www.youtube.com/embed/Nn6yrpIhROE" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
            <div class="col-12">
                <div class="slider-title wow bounceInLeft" data-wow-duration="1s">
                    Youtube Videos<span class="color-3">.</span>
                </div>
            </div>
            <div class="col-6 col-md-4 text-center pt-9 mx-auto">
                <iframe width="100%" height="190" src="https://www.youtube.com/embed/t0lc1_4ADXw" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
            <div class="col-6 col-md-4 text-center pt-9 mx-auto">
                <iframe width="100%" height="190" src="https://www.youtube.com/embed/QE_Cq9icNTo" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
            <div class="col-6 col-md-4 text-center pt-9 mx-auto">
                <iframe width="100%" height="190" src="https://www.youtube.com/embed/Nn6yrpIhROE" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
            <div class="col-12">
                <div class="slider-title wow bounceInLeft" data-wow-duration="1s">
                    Testimonials<span class="color-3">.</span>
                </div>
            </div>
            <div class="col-6 col-md-4 text-center pt-9 mx-auto">
                <iframe width="100%" height="190" src="https://www.youtube.com/embed/t0lc1_4ADXw" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
            <div class="col-6 col-md-4 text-center pt-9 mx-auto">
                <iframe width="100%" height="190" src="https://www.youtube.com/embed/QE_Cq9icNTo" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
            <div class="col-6 col-md-4 text-center pt-9 mx-auto">
                <iframe width="100%" height="190" src="https://www.youtube.com/embed/Nn6yrpIhROE" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
            <div class="col-12">
                <div class="slider-title wow bounceInLeft" data-wow-duration="1s">
                    Edits<span class="color-3">.</span>
                </div>
            </div>
            <div class="col-6 col-md-4 text-center pt-9 mx-auto">
                <iframe width="100%" height="190" src="https://www.youtube.com/embed/t0lc1_4ADXw" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
            <div class="col-6 col-md-4 text-center pt-9 mx-auto">
                <iframe width="100%" height="190" src="https://www.youtube.com/embed/QE_Cq9icNTo" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
            <div class="col-6 col-md-4 text-center pt-9 mx-auto">
                <iframe width="100%" height="190" src="https://www.youtube.com/embed/Nn6yrpIhROE" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
        </div>
    </div>
</section>

<?php include "footer.php" ?>