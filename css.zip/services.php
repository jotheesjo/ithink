<?php include "header.php" ?>
<img src="img/innr-banner.jpg" alt="" class="w-100">
<section class="bg-2">
    <div class="container pt-10">
        <div class="row">
            <div class="col-md-11 m-auto text-center">
                <div class="slider-title">
                    Our Services<span class="color-3">.</span>
                </div>
                <p class="text-white">
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Delectus sequi porro quas quam hic unde, pariatur voluptate iure at illum nam, sunt ad quisquam perferendis inventore possimus tenetur cupiditate eum?
                </p>
            </div>
        </div>
        <div class="row">

            <div class="col-md-4 p-5 m-auto">
                <a data-fancybox="style" data-src="#style3" href="javascript:;">
                    <div class="card border wow bounceInUp bg-1" data-wow-duration="1s">
                        <img class="card-img-top" src="img/people-img.png" alt="...">
                        <div class="card-body text-center text-dark">
                            <h3 class=" mb-3 text-white font-weight-bolder wow bounceInLeft" data-wow-duration="1s">
                                Service 1
                            </h3>
                            <p class="text-white text-justify">
                                Lorem ipsum dolor sit amet consectetur adipisicing elit. Delectus sequi porro quas quam hic unde, pariatur . . .
                            </p>
                        </div>
                    </div>
                </a>
                <div id="style3" style="display: none;width:100%;max-width:100%;height: 100%;">
                    <button type="button" class="close" data-dismiss="modal"></button> <br>
                    <div class="row">
                        <div class="col-md-6">
                            <img class="card-img-top mb-3" src="img/people-img.png" alt="...">
                        </div>
                        <div class="col-md-6">
                            <h3 class="off" style="font-weight: 900;">
                                HAIR SALON
                            </h3>
                            <h3 class=" mb-3 color-03 font-dancing">
                                Hair Spa
                            </h3>
                            <P class="text-justify">A treatment for hair re-development, hair spa is an answer for some issues identified with hair. It isn't just a treatment for hair re-development, however it additionally takes care of issues like dandruff, balding, unpleasant, and dull hair. Hair spa helps in molding the scalp, courses blood, and gives unwinding.</P>
                            <P class="text-justify">The master beauticians at QT5 Glenys ensure that what you get is the most ideal answer for all hair issues you have. Spa for molding helps in making the hair follicles more grounded. The principle motivation behind this molding is sustaining the underlying foundations of the hair and advancing hair re-development. The oil discharge of the scalp can be controlled. It rehydrates the scalp without causing dryness of the scalp.</P>
                            <P class="text-justify">On the off chance that you need to have a decent and sound hair, normalizing the oil discharge of the scalp is significant. Over-discharge of oil can drove your hair to be clingy. Consequently, it is fundamental that parity is kept up. A decent beautician consistently deals with these perspectives.</P>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-4 p-5 m-auto">
                <a data-fancybox="style" data-src="#style3" href="javascript:;">
                    <div class="card border wow bounceInUp bg-1" data-wow-duration="1s">
                        <img class="card-img-top" src="img/people-img.png" alt="...">
                        <div class="card-body text-center text-dark">
                            <h3 class=" mb-3 text-white font-weight-bolder wow bounceInLeft" data-wow-duration="1s">
                                Service 1
                            </h3>
                            <p class="text-white text-justify">
                                Lorem ipsum dolor sit amet consectetur adipisicing elit. Delectus sequi porro quas quam hic unde, pariatur . . .
                            </p>
                        </div>
                    </div>
                </a>
                <div id="style3" style="display: none;width:100%;max-width:100%;height: 100%;">
                    <button type="button" class="close" data-dismiss="modal"></button> <br>
                    <div class="row">
                        <div class="col-md-6">
                            <img class="card-img-top mb-3" src="img/people-img.png" alt="...">
                        </div>
                        <div class="col-md-6">
                            <h3 class="off" style="font-weight: 900;">
                                HAIR SALON
                            </h3>
                            <h3 class=" mb-3 color-03 font-dancing">
                                Hair Spa
                            </h3>
                            <P class="text-justify">A treatment for hair re-development, hair spa is an answer for some issues identified with hair. It isn't just a treatment for hair re-development, however it additionally takes care of issues like dandruff, balding, unpleasant, and dull hair. Hair spa helps in molding the scalp, courses blood, and gives unwinding.</P>
                            <P class="text-justify">The master beauticians at QT5 Glenys ensure that what you get is the most ideal answer for all hair issues you have. Spa for molding helps in making the hair follicles more grounded. The principle motivation behind this molding is sustaining the underlying foundations of the hair and advancing hair re-development. The oil discharge of the scalp can be controlled. It rehydrates the scalp without causing dryness of the scalp.</P>
                            <P class="text-justify">On the off chance that you need to have a decent and sound hair, normalizing the oil discharge of the scalp is significant. Over-discharge of oil can drove your hair to be clingy. Consequently, it is fundamental that parity is kept up. A decent beautician consistently deals with these perspectives.</P>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-4 p-5 m-auto">
                <a data-fancybox="style" data-src="#style3" href="javascript:;">
                    <div class="card border wow bounceInUp bg-1" data-wow-duration="1s">
                        <img class="card-img-top" src="img/people-img.png" alt="...">
                        <div class="card-body text-center text-dark">
                            <h3 class=" mb-3 text-white font-weight-bolder wow bounceInLeft" data-wow-duration="1s">
                                Service 1
                            </h3>
                            <p class="text-white text-justify">
                                Lorem ipsum dolor sit amet consectetur adipisicing elit. Delectus sequi porro quas quam hic unde, pariatur . . .
                            </p>
                        </div>
                    </div>
                </a>
                <div id="style3" style="display: none;width:100%;max-width:100%;height: 100%;">
                    <button type="button" class="close" data-dismiss="modal"></button> <br>
                    <div class="row">
                        <div class="col-md-6">
                            <img class="card-img-top mb-3" src="img/people-img.png" alt="...">
                        </div>
                        <div class="col-md-6">
                            <h3 class="off" style="font-weight: 900;">
                                HAIR SALON
                            </h3>
                            <h3 class=" mb-3 color-03 font-dancing">
                                Hair Spa
                            </h3>
                            <P class="text-justify">A treatment for hair re-development, hair spa is an answer for some issues identified with hair. It isn't just a treatment for hair re-development, however it additionally takes care of issues like dandruff, balding, unpleasant, and dull hair. Hair spa helps in molding the scalp, courses blood, and gives unwinding.</P>
                            <P class="text-justify">The master beauticians at QT5 Glenys ensure that what you get is the most ideal answer for all hair issues you have. Spa for molding helps in making the hair follicles more grounded. The principle motivation behind this molding is sustaining the underlying foundations of the hair and advancing hair re-development. The oil discharge of the scalp can be controlled. It rehydrates the scalp without causing dryness of the scalp.</P>
                            <P class="text-justify">On the off chance that you need to have a decent and sound hair, normalizing the oil discharge of the scalp is significant. Over-discharge of oil can drove your hair to be clingy. Consequently, it is fundamental that parity is kept up. A decent beautician consistently deals with these perspectives.</P>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-4 p-5 m-auto">
                <a data-fancybox="style" data-src="#style3" href="javascript:;">
                    <div class="card border wow bounceInUp bg-1" data-wow-duration="1s">
                        <img class="card-img-top" src="img/people-img.png" alt="...">
                        <div class="card-body text-center text-dark">
                            <h3 class=" mb-3 text-white font-weight-bolder wow bounceInLeft" data-wow-duration="1s">
                                Service 1
                            </h3>
                            <p class="text-white text-justify">
                                Lorem ipsum dolor sit amet consectetur adipisicing elit. Delectus sequi porro quas quam hic unde, pariatur . . .
                            </p>
                        </div>
                    </div>
                </a>
                <div id="style3" style="display: none;width:100%;max-width:100%;height: 100%;">
                    <button type="button" class="close" data-dismiss="modal"></button> <br>
                    <div class="row">
                        <div class="col-md-6">
                            <img class="card-img-top mb-3" src="img/people-img.png" alt="...">
                        </div>
                        <div class="col-md-6">
                            <h3 class="off" style="font-weight: 900;">
                                HAIR SALON
                            </h3>
                            <h3 class=" mb-3 color-03 font-dancing">
                                Hair Spa
                            </h3>
                            <P class="text-justify">A treatment for hair re-development, hair spa is an answer for some issues identified with hair. It isn't just a treatment for hair re-development, however it additionally takes care of issues like dandruff, balding, unpleasant, and dull hair. Hair spa helps in molding the scalp, courses blood, and gives unwinding.</P>
                            <P class="text-justify">The master beauticians at QT5 Glenys ensure that what you get is the most ideal answer for all hair issues you have. Spa for molding helps in making the hair follicles more grounded. The principle motivation behind this molding is sustaining the underlying foundations of the hair and advancing hair re-development. The oil discharge of the scalp can be controlled. It rehydrates the scalp without causing dryness of the scalp.</P>
                            <P class="text-justify">On the off chance that you need to have a decent and sound hair, normalizing the oil discharge of the scalp is significant. Over-discharge of oil can drove your hair to be clingy. Consequently, it is fundamental that parity is kept up. A decent beautician consistently deals with these perspectives.</P>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>

<?php include "footer.php" ?>